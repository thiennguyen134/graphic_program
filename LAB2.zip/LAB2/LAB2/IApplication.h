#pragma once

#include <cstdint>

class IApplication {
public:
    static bool IsKeyDown(uint16_t key);

};
